package com.example.dailyflow
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Entity(tableName="tasks")
data class Task(@PrimaryKey(autoGenerate=true) val id:Int=0,val title:String,val notes:String="",val dueDate:String="",val done:Boolean=false,val createdAt:Long=System.currentTimeMillis(),val priority:String="Normal",val category:String="Personal")
@Dao interface TaskDao {
 @Query("SELECT * FROM tasks ORDER BY done ASC, CASE priority WHEN 'High' THEN 0 WHEN 'Normal' THEN 1 ELSE 2 END, createdAt DESC") fun observeTasks():Flow<List<Task>>
 @Query("SELECT * FROM tasks") suspend fun getAllTasks():List<Task>
 @Insert suspend fun insert(task:Task)
 @Insert suspend fun insertAll(tasks:List<Task>)
 @Update suspend fun update(task:Task)
 @Delete suspend fun delete(task:Task)
 @Query("DELETE FROM tasks") suspend fun clearAll()
 @Query("SELECT COUNT(*) FROM tasks WHERE done=1") fun observeCompletedCount():Flow<Int>
 @Query("SELECT COUNT(*) FROM tasks WHERE done=0") fun observePendingCount():Flow<Int>
}
@Database(entities=[Task::class],version=2,exportSchema=false)
abstract class TaskDatabase:RoomDatabase(){ abstract fun taskDao():TaskDao
 companion object { @Volatile private var INSTANCE:TaskDatabase?=null
 private val MIGRATION_1_2=object:Migration(1,2){override fun migrate(db:androidx.sqlite.db.SupportSQLiteDatabase){db.execSQL("ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'Normal'");db.execSQL("ALTER TABLE tasks ADD COLUMN category TEXT NOT NULL DEFAULT 'Personal'")}}
 fun get(context:Context):TaskDatabase=INSTANCE?: synchronized(this){INSTANCE?:Room.databaseBuilder(context.applicationContext,TaskDatabase::class.java,"dailyflow.db").addMigrations(MIGRATION_1_2).build().also{INSTANCE=it}}
 }}
