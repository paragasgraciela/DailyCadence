package com.example.dailyflow
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
private val Blue=Color(0xFF4263EB); private val Ink=Color(0xFF17243A); private val Muted=Color(0xFF778196); private val Canvas=Color(0xFFF5F7FB)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val dao=TaskDatabase.get(this).taskDao();setContent{MaterialTheme(colorScheme=lightColorScheme(primary=Blue,background=Canvas,surface=Color.White,onSurface=Ink)){DailyCadenceScreen(dao)}}}}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun DailyCadenceScreen(dao:TaskDao){
 val context=LocalContext.current;val scope= rememberCoroutineScope();val tasks by dao.observeTasks().collectAsStateWithLifecycle(initialValue= emptyList());val done by dao.observeCompletedCount().collectAsStateWithLifecycle(initialValue=0);val pending by dao.observePendingCount().collectAsStateWithLifecycle(initialValue=0)
 var page by remember{mutableStateOf("Tasks")};var editor by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<Task?>(null)};var date by remember{mutableStateOf("")}
 val backup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)scope.launch{val a=JSONArray();dao.getAllTasks().forEach{t->a.put(JSONObject().put("title",t.title).put("notes",t.notes).put("dueDate",t.dueDate).put("done",t.done).put("createdAt",t.createdAt).put("priority",t.priority).put("category",t.category))};context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(a.toString(2))}}}
 val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)scope.launch{runCatching{val raw=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:"[]";val a=JSONArray(raw);val imported=(0 until a.length()).map{i->val o=a.getJSONObject(i);Task(title=o.optString("title"),notes=o.optString("notes"),dueDate=o.optString("dueDate"),done=o.optBoolean("done"),createdAt=o.optLong("createdAt",System.currentTimeMillis()),priority=o.optString("priority","Normal"),category=o.optString("category","Personal"))}.filter{it.title.isNotBlank()};dao.clearAll();dao.insertAll(imported)}}}
 val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)scheduleReminder(context)}
 Scaffold(containerColor=Canvas,topBar={TopAppBar(title={Column{Text("DailyCadence",fontWeight=FontWeight.Bold);Text("Make today count.",style=MaterialTheme.typography.labelMedium,color=Muted)}},actions={IconButton(onClick={if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permission.launch(Manifest.permission.POST_NOTIFICATIONS)else scheduleReminder(context)}){Icon(Icons.Default.Notifications,"Reminders",tint=Blue)}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Canvas))},floatingActionButton={FloatingActionButton(onClick={editing=null;editor=true},containerColor=Blue){Icon(Icons.Default.Add,"Add task",tint=Color.White)}}){pad->
 LazyColumn(Modifier.fillMaxSize().padding(pad),contentPadding=PaddingValues(18.dp,12.dp,18.dp,100.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 item{SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()){listOf("Tasks","Calendar","Insights").forEachIndexed{i,s->SegmentedButton(page==s,{page=s},shape=SegmentedButtonDefaults.itemShape(i,3)){Text(s)}}}}
 if(page=="Tasks"){item{Text("Your overview",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("To do",pending.toString(),Modifier.weight(1f));Stat("Completed",done.toString(),Modifier.weight(1f))}};item{Text("Your tasks",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)};items(tasks,key={it.id}){t->TaskItem(t,{scope.launch{dao.update(t.copy(done=!t.done))}},{editing=t;editor=true},{scope.launch{dao.delete(t)}})}}
 else if(page=="Calendar"){item{Text("Calendar",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},modifier=Modifier.fillMaxWidth());Text("Tasks scheduled for this date")};items(tasks.filter{date.isNotBlank()&&it.dueDate==date},key={it.id}){t->TaskItem(t,{scope.launch{dao.update(t.copy(done=!t.done))}},{editing=t;editor=true},{scope.launch{dao.delete(t)}})}}
 else{item{Text("Productivity insights",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Stat("Total tasks",tasks.size.toString(),Modifier.fillMaxWidth());Stat("Completion",if(tasks.isEmpty())"0%" else "${done*100/tasks.size}%",Modifier.fillMaxWidth());Text("High priority: ${tasks.count{it.priority=="High"}}");Text("Normal priority: ${tasks.count{it.priority=="Normal"}}");Text("Low priority: ${tasks.count{it.priority=="Low"}}")};item{Text("Backup and restore",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={backup.launch("dailycadence-backup.json")},modifier=Modifier.weight(1f)){Text("Export")};OutlinedButton(onClick={restore.launch(arrayOf("application/json","text/*"))},modifier=Modifier.weight(1f)){Text("Restore")}};Text("Restore replaces tasks currently on this device. Export a backup first.",color=Muted,style=MaterialTheme.typography.bodySmall)}}
 item{Text("Offline-first. Your tasks are stored on this device.",color=Muted,style=MaterialTheme.typography.labelSmall)}
 }}
 if(editor)TaskEditor(editing,{editor=false}){title,notes,due,priority,category->scope.launch{val old=editing;if(old==null)dao.insert(Task(title=title,notes=notes,dueDate=due,priority=priority,category=category))else dao.update(old.copy(title=title,notes=notes,dueDate=due,priority=priority,category=category))};editor=false}
}
@Composable private fun TaskEditor(task:Task?,dismiss:()->Unit,save:(String,String,String,String,String)->Unit){var title by remember(task){mutableStateOf(task?.title?:"")};var notes by remember(task){mutableStateOf(task?.notes?:"")};var due by remember(task){mutableStateOf(task?.dueDate?:"")};var priority by remember(task){mutableStateOf(task?.priority?:"Normal")};var category by remember(task){mutableStateOf(task?.category?:"Personal")};AlertDialog(onDismissRequest=dismiss,title={Text(if(task==null)"Add task" else "Edit task")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Title")});OutlinedTextField(notes,{notes=it},label={Text("Notes")});OutlinedTextField(due,{due=it},label={Text("Due date YYYY-MM-DD")});Text("Priority");Row{listOf("Low","Normal","High").forEach{FilterChip(priority==it,{priority=it},label={Text(it)})}};Text("Category");Row{listOf("Personal","Study","Work").forEach{FilterChip(category==it,{category=it},label={Text(it)})}}}},confirmButton={TextButton(enabled=title.isNotBlank(),onClick={save(title.trim(),notes.trim(),due.trim(),priority,category)}){Text("Save")}},dismissButton={TextButton(onClick=dismiss){Text("Cancel")}})}
@Composable private fun TaskItem(t:Task,toggle:()->Unit,edit:()->Unit,delete:()->Unit){Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(t.done,{toggle()});Column(Modifier.weight(1f)){Text(t.title,fontWeight=FontWeight.SemiBold);if(t.notes.isNotBlank())Text(t.notes,color=Muted);Text("${t.category} • ${t.priority} • ${t.dueDate}",color=Blue,style=MaterialTheme.typography.labelSmall)};IconButton(onClick=edit){Icon(Icons.Default.Edit,"Edit",tint=Blue)};IconButton(onClick=delete){Icon(Icons.Default.Delete,"Delete",tint=Muted)}}}}
@Composable private fun Stat(label:String,value:String,modifier:Modifier){Card(modifier=modifier,colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(14.dp)){Text(label,color=Muted);Text(value,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=Blue)}}}
private fun scheduleReminder(context:android.content.Context){val r=PeriodicWorkRequestBuilder<ReminderWorker>(1,TimeUnit.DAYS).build();WorkManager.getInstance(context).enqueueUniquePeriodicWork("daily_cadence_reminder",ExistingPeriodicWorkPolicy.UPDATE,r)}
