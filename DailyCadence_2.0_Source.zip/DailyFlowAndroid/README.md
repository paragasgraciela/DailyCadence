# DailyCadence 2.0

Offline-first task planner with dashboard counts, task editing, priorities, categories, date-based task view, productivity insights, JSON backup/restore, and Room database migration.

Application ID remains `com.example.dailyflow` to support updating an existing install. Build with Java 17, Android SDK 35 and Gradle 8.9.
