# DailyFlow Android

A starter Android productivity app built with Kotlin, Jetpack Compose, Room, and WorkManager.

## Included in this starter
- Minimalist dashboard
- Add tasks with optional notes
- Mark tasks complete / incomplete
- Delete tasks
- Local Room database (no sign-in or internet required)
- Daily reminder scheduling using WorkManager
- Notification permission request on Android 13+

## Build an APK using Android Studio
1. Install the latest stable Android Studio.
2. Open the `DailyFlowAndroid` folder in Android Studio.
3. Allow Gradle to sync and install the Android SDK platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run to install the app for testing.
6. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio will show the generated APK location, normally:
   `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- This is a starter project, not a signed release build.
- The daily reminder is periodic; Android WorkManager controls the exact delivery time and may delay it to save battery.
- The app stores task data locally on the device.
- The starter uses package name `com.example.dailyflow`. Change it before publishing.
