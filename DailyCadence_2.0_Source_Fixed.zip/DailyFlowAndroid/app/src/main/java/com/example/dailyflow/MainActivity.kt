package com.example.dailyflow

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF17243A)
private val Blue = Color(0xFF4263EB)
private val Canvas = Color(0xFFF5F7FB)
private val Muted = Color(0xFF778196)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = TaskDatabase.get(this).taskDao()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Canvas, surface = Color.White, onSurface = Ink)) {
                DailyCadenceScreen(dao)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyCadenceScreen(dao: TaskDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tasks by dao.observeTasks().collectAsStateWithLifecycle(initialValue = emptyList())
    val completed by dao.observeCompletedCount().collectAsStateWithLifecycle(initialValue = 0)
    val pending by dao.observePendingCount().collectAsStateWithLifecycle(initialValue = 0)
    var tab by remember { mutableStateOf("Overview") }
    var editing by remember { mutableStateOf<Task?>(null) }
    var editorOpen by remember { mutableStateOf(false) }
    var date by remember { mutableStateOf("") }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val array = JSONArray()
            dao.getAllTasks().forEach { t ->
                array.put(JSONObject().put("title", t.title).put("notes", t.notes).put("dueDate", t.dueDate)
                    .put("done", t.done).put("createdAt", t.createdAt).put("priority", t.priority).put("category", t.category))
            }
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(array.toString(2)) }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "[]"
                val array = JSONArray(raw)
                val imported = (0 until array.length()).map { i ->
                    val o = array.getJSONObject(i)
                    Task(title = o.optString("title"), notes = o.optString("notes"), dueDate = o.optString("dueDate"),
                        done = o.optBoolean("done"), createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                        priority = o.optString("priority", "Normal"), category = o.optString("category", "Personal"))
                }.filter { it.title.isNotBlank() }
                dao.clearAll()
                dao.insertAll(imported)
            }
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scheduleReminder(context)
    }

    Scaffold(
        containerColor = Canvas,
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("DailyCadence", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Make today count.", style = MaterialTheme.typography.labelMedium, color = Muted)
                } },
                actions = {
                    IconButton(onClick = {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else scheduleReminder(context)
                    }) { Icon(Icons.Default.Notifications, contentDescription = "Enable reminders", tint = Blue) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Canvas)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; editorOpen = true }, containerColor = Blue, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Add task")
            }
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("Overview", "Calendar", "Insights").forEachIndexed { index, label ->
                        SegmentedButton(tab == label, { tab = label }, shape = SegmentedButtonDefaults.itemShape(index, 3)) { Text(label) }
                    }
                }
            }
            when (tab) {
                "Overview" -> {
                    item {
                        Text("Your overview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("To do", pending.toString(), Modifier.weight(1f), Blue)
                            StatCard("Completed", completed.toString(), Modifier.weight(1f), Color(0xFF159B75))
                        }
                    }
                    item {
                        val total = pending + completed
                        val progress = if (total == 0) 0f else completed.toFloat() / total
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.TaskAlt, null, tint = Blue)
                                    Spacer(Modifier.width(8.dp)); Text("Daily progress", fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.weight(1f)); Text("${(progress * 100).toInt()}%", color = Blue)
                                }
                                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                                Text("$completed of $total tasks completed", color = Muted)
                            }
                        }
                    }
                    item { Text("Your tasks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    if (tasks.isEmpty()) item { EmptyCard() } else items(tasks, key = { it.id }) { task ->
                        TaskCard(task, { scope.launch { dao.update(task.copy(done = !task.done)) } },
                            { editing = task; editorOpen = true }, { scope.launch { dao.delete(task) } })
                    }
                }
                "Calendar" -> {
                    item {
                        Text("Calendar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text(if (date.isBlank()) "Enter a date to see scheduled tasks" else "Tasks for $date", fontWeight = FontWeight.SemiBold)
                    }
                    val matching = tasks.filter { date.isNotBlank() && it.dueDate == date }
                    if (date.isNotBlank() && matching.isEmpty()) item { EmptyCard("No tasks for this date") }
                    else items(matching, key = { it.id }) { task ->
                        TaskCard(task, { scope.launch { dao.update(task.copy(done = !task.done)) } },
                            { editing = task; editorOpen = true }, { scope.launch { dao.delete(task) } })
                    }
                }
                else -> {
                    item {
                        Text("Productivity insights", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("Total tasks", tasks.size.toString(), Modifier.weight(1f), Blue)
                            StatCard("Completion", if (tasks.isEmpty()) "0%" else "${completed * 100 / tasks.size}%",
                                Modifier.weight(1f), Color(0xFF159B75))
                        }
                    }
                    item { Text("Tasks by priority", fontWeight = FontWeight.Bold) }
                    listOf("High", "Normal", "Low").forEach { p ->
                        item { Text("$p: ${tasks.count { it.priority == p }} tasks", color = Muted) }
                    }
                    item { Text("Backup and restore", fontWeight = FontWeight.Bold) }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { backupLauncher.launch("dailycadence-backup.json") }, modifier = Modifier.weight(1f)) { Text("Export backup") }
                            OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.weight(1f)) { Text("Restore backup") }
                        }
                        Text("Restoring replaces the tasks currently on this device. Export a backup first.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("Your tasks are stored on this device. DailyCadence works offline.", color = Muted, style = MaterialTheme.typography.labelSmall) }
        }
    }
    if (editorOpen) TaskEditor(editing, { editorOpen = false }) { title, notes, due, priority, category ->
        scope.launch {
            val old = editing
            if (old == null) dao.insert(Task(title = title, notes = notes, dueDate = due, priority = priority, category = category))
            else dao.update(old.copy(title = title, notes = notes, dueDate = due, priority = priority, category = category))
        }
        editorOpen = false
    }
}

@Composable
private fun TaskEditor(task: Task?, onDismiss: () -> Unit, onSave: (String, String, String, String, String) -> Unit) {
    var title by remember(task) { mutableStateOf(task?.title ?: "") }
    var notes by remember(task) { mutableStateOf(task?.notes ?: "") }
    var due by remember(task) { mutableStateOf(task?.dueDate ?: "") }
    var priority by remember(task) { mutableStateOf(task?.priority ?: "Normal") }
    var category by remember(task) { mutableStateOf(task?.category ?: "Personal") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (task == null) "Add a task" else "Edit task") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Task title") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") })
            OutlinedTextField(due, { due = it }, label = { Text("Due date (YYYY-MM-DD)") }, singleLine = true)
            Text("Priority")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("Low", "Normal", "High").forEach { FilterChip(selected = priority == it, onClick = { priority = it }, label = { Text(it) }) }
            }
            Text("Category")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("Personal", "Study", "Work").forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }) }
            }
        } },
        confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { onSave(title.trim(), notes.trim(), due.trim(), priority, category) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun TaskCard(task: Task, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(task.done, { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.SemiBold, color = if (task.done) Muted else Ink)
                if (task.notes.isNotBlank()) Text(task.notes, color = Muted, style = MaterialTheme.typography.bodySmall)
                Text("${task.category} • ${task.priority}${if (task.dueDate.isNotBlank()) " • ${task.dueDate}" else ""}",
                    color = Blue, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit task", tint = Blue) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = Muted) }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
            Text(value, color = accent, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EmptyCard(message: String = "A clear space to begin") {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(message, fontWeight = FontWeight.SemiBold)
            Text("Tap + to add your first task.", color = Muted)
        }
    }
}

private fun scheduleReminder(context: android.content.Context) {
    val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        "dailyflow_daily_reminder", ExistingPeriodicWorkPolicy.UPDATE, request
    )
}
