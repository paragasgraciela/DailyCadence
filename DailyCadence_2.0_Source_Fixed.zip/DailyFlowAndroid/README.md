# DailyCadence 2.0

Offline-first Android task planner.

## Features
- Dashboard with pending/completed counts and progress
- Add, edit, complete, and delete tasks
- Priority levels: Low, Normal, High
- Categories: Personal, Study, Work
- Date-based task view
- Productivity insights
- JSON backup export and restore
- Daily reminder scheduling
- Room database migration from version 1 to version 2

## Build
Use Java 17, Android SDK 35, and the Gradle wrapper or Gradle 8.9.

The Android application ID remains `com.example.dailyflow` and the database filename remains `dailyflow.db` to support upgrades from the original DailyFlow app.
